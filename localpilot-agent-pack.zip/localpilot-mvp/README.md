# LocalPilot (MVP)

A Windows-first VS Code extension that connects to QVAC's OpenAI-compatible local server. It starts a QVAC server, loads a small QVAC model, provides local chat, and explains selected code.

## Requirements

- Windows 10/11
- VS Code
- Node.js 20+ and npm
- 16 GB RAM recommended for this prototype; CPU-only inference may be slower
- Internet for initial installation/model download; offline use after the model is cached

## 1. Install QVAC CLI

Open PowerShell and run:

```powershell
npm install -g @qvac/cli
qvac --help
```

If `qvac` is not found, close and reopen PowerShell/VS Code so PATH refreshes.

## 2. Install dependencies and compile the extension

From this project folder:

```powershell
npm install
npm run compile
```

## 3. Launch the extension

1. Open this folder in VS Code.
2. Press **F5** (Run > Start Debugging).
3. A second **Extension Development Host** window opens.
4. Press `Ctrl+Shift+P`, run **LocalPilot: Start QVAC Local Model**.
5. Wait for QVAC to download/cache the configured model and start the server. The first start can take a while.
6. Run **LocalPilot: Chat with Local Model** or select code and run **LocalPilot: Explain Selected Code**.

The generated config uses the QVAC CLI model identifier `QWEN3_600M_INST_Q4` with the API model name `localpilot-model` and a 4096-token context setting. If the installed QVAC version does not recognize this identifier, update the `model` value in `src/extension.ts` to a model ID supported by that installed CLI.

## 4. Verify offline behavior

After the model has fully downloaded and successfully answered once:

1. Stop QVAC with **LocalPilot: Stop QVAC Server**.
2. Disable Wi-Fi/Ethernet.
3. Start QVAC again and repeat a chat prompt.
4. Record the result for the hackathon demo.

If the model or runtime still tries to download something, the offline test is not yet passed. Do not claim offline operation until this succeeds.

## Commands

- `LocalPilot: Start QVAC Local Model`
- `LocalPilot: Chat with Local Model`
- `LocalPilot: Explain Selected Code`
- `LocalPilot: Stop QVAC Server`

## Important MVP limitations

- This prototype uses the QVAC local HTTP server on `127.0.0.1:11434`; prompts are sent to that local endpoint, not a cloud API.
- The extension currently supports one configured model and non-streaming responses.
- The `Stop` command stops the process launched by this extension, but a process spawned by a shell may not always terminate its entire child-process tree on Windows. Check Task Manager if the server remains running.
- Test QVAC CLI commands and model IDs against the installed QVAC release. The SDK/CLI evolves, so pin and record the working version before submission.
- Do not add telemetry, cloud fallback, or external prompt logging to the hackathon MVP.

## Packaging

```powershell
npx @vscode/vsce package
```

This creates a `.vsix` package you can install with **Extensions: Install from VSIX...**.
